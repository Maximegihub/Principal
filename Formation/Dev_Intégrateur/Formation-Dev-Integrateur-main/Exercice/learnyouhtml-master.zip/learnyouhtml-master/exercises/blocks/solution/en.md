# Well done!

It was a bit difficult isn't it? Anyway, you did this!

There is a lot left to talk about tags, semantic and conventions about writing HTML markup. We keep this up to you. Read more about semantic and new HTML5 tags here: <https://developer.mozilla.org/en/docs/Web/HTML/Element>

Let's move forward! You know how to create a page, but you still need to get know how to connect one page to another. In following exercise we will consider how to reference documents between each other - the core principle of how the web works!
