# Good!

Now you know how to make a links between documents. Cool, right?

Are you wondering about how we can create a button or input field with html? Actually, HTML provides special tag for that purposes. Moreover, you can even compose few control elements in a form. In the next exercise we're gonna take a look at forms and form elements.
