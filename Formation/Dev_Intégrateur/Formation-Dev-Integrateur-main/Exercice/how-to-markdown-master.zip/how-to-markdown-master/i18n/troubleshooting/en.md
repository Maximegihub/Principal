----
# Wo-ops, something isn't working. But don't panic!
----

## Check your solution:

`Solution ===================`

```
%solution%
```

`Your Attempt ===================`

```
%attempt%
```

`Difference ===================`

```
%diff%
```

## Additional troubleshooting:

* Did you type the name of the file correctly? You can check by running `ls %filename%`, if you see `ls: cannot access %filename%: No such file or directory` then you should create new file / rename existing or change directories to the one with file
* Make sure you didn't omit parens, since otherwise compiler would not be able to parse it
* Make sure you didn't do any typos in the string itself
