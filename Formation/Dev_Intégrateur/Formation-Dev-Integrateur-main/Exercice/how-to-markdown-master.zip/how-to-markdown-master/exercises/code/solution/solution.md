# Code

```js
const add = (a, b) => a + b;
```
