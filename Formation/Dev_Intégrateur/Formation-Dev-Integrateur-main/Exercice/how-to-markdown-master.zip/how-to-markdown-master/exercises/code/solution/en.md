# Awesome!

Now you can embed code snippets into Markdown documents. That is yet another thing that is used almost everywhere.

In the next exercise we will take a look at tables in Markdown.
