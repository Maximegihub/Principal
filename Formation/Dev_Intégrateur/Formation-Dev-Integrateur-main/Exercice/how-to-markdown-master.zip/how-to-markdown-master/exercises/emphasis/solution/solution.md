# Emphasis

It's very easy to use _italic_, **bold** and _**combined**_ emphasis in Markdown!
