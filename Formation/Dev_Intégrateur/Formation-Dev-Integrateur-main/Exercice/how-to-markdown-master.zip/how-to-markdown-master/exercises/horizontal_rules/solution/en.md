# Nice job!

It was a pretty easy exercise, but sometimes horizontal rules are very handy, so you should know how to create them.

In the next exercise we will take a look at inline HTML in Markdown.
