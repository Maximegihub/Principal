# 完工！

你可以使用 HTML 编写任何内容：定义列表，嵌入社交网络中的内容，嵌入 YouTube 视频，等等。只需要在你的 MarkDown 文档的合适位置插入 HTML 标记即可。

下一个练习我们将学习 Markdown 的 GFM 语法。
