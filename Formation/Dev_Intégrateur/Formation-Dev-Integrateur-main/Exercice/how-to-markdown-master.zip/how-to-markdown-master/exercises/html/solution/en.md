# Works!

You can use HTML for creating anything you want: definition lists, embedding posts from social networks, embedding videos from YouTube, etc. Just type HTML tags right in your Markdown document and see how it works.

In the next exercise we will take a look at GFM in Markdown.
