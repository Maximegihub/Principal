# Great!

There is one more thing. You may have any order of numbers in your ordered lists. For example this notation works well:

    0. only zeros
    0. only zeros
    0. only zeros

    10. any order
    5. any order
    2. any order
    7. any order


0. only zeros
0. only zeros
0. only zeros


5. any order
10. any order
2. any order
7. any order

Markdown parser is pretty clever in creating the correct order. This approach may be very useful for supporting big ordered lists.

In the next exercise we will take a look at references in Markdown.
