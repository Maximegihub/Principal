# 非常棒！

额外强调一下，你可以在有序列表中按任意顺序编排项目。请参考下面的例子：

    0. only zeros
    0. only zeros
    0. only zeros

    10. any order
    5. any order
    2. any order
    7. any order

格式化后的效果如下：

0. only zeros
0. only zeros
0. only zeros

5. any order
10. any order
2. any order
7. any order

Markdown 很聪明，会创建一个正确的顺序。在你维护一个很大的列表时，这个功能非常有用。

下一个练习我们将学习 Markdown 的引用语法。
