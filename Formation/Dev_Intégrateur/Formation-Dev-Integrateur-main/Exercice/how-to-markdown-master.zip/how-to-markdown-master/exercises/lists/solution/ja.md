# 見事！

一つ注意事項があります。 順序つきリストに、他の数字をつけたいかもしれません。 たとえば、この表記法はうまくいきます。


    0. only zeros
    0. only zeros
    0. only zeros

    10. any order
    5. any order
    2. any order
    7. any order


0. only zeros
0. only zeros
0. only zeros


5. any order
10. any order
2. any order
7. any order

Markdownのパーザーは、正しい順序を作成するのには非常に賢いです。 このアプローチは、大規模な順序付きリストをサポートするのに非常に便利です。

次の演習では、Markdownのリンク（参照）について見ていきます。
