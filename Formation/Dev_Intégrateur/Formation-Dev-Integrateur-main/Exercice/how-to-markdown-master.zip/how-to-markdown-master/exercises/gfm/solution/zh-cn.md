# 恭喜你！

成功的完成本教程！现在你已经熟悉 MarkDown，并且知道如何编辑和阅读 MarkDown 文档。

接下来打算做点什么？在自己的工作和生活中编写 MarkDown 文档吧。把自己项目中的 `README`文件重新编辑一下，开始在博客中用 MarkDown 编写博文，或者其他什么。

不管怎样，MarkDown 的知识是非常有用的。

感谢你使用本教程。欢迎继续学习 [nodeschool](http://nodeschool.io) 上的其他教程。
