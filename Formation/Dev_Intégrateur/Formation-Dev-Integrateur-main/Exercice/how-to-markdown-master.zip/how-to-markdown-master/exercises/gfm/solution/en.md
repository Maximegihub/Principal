# Congratulations!

You finished this workshopper! Now you are familiar with Markdown and know how to write and read Markdown documents.

What should you do next? Just write some Markdown. Rewrite the `README`-file of your project in Markdown, start to write posts in your blog in Markdown, whatever.

Anyway, knowledge of Markdown is a very nice skill that will be useful.

Thank you for using this workshopper. Check out other workshoppers on <http://nodeschool.io>.
