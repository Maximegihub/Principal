# Very well!

You did a cool table of the World population. Now do you realize how awesome tables in Markdown are? They are easy and readable, even in plain files.

In the next exercise we will take a look at horizontal rules in Markdown.
