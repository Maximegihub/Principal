# Tables

| Year | World population |
| :--: | ---------------- |
| 1960 | 3 Billion        |
| 1980 | 4 Billion        |
| 2000 | 6 Billion        |
