# You did it!

Congratulations! You wrote your first paragraph in Markdown! Quite simple, isn't it?

If you are already familiar with HTML, you may guess that your solution will be rendered in such markup:

```html
<p>Hello, world!</p>
```

Paragraphs are separated by a blank line, so if you need to create two or more paragraphs, you have to write something like this:

```
I am the first paragraph.

I am the second one.
```

In the next exercise we will take a look at headings in Markdown.
