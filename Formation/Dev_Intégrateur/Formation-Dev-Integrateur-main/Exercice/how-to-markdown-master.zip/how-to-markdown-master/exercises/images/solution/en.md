# Cool!

Now you learned how to add an image in Markdown. This is a common style for images, but some parsers provide additional tools for alignment, adding classes and other styles.

In the next exercise we will take a look at blockquotes in Markdown.
