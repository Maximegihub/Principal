# 酷！

Now you learned how to create a link in Markdown. This is a common style for links, but some parsers provide additional tools for alignment, adding classes and other styles.

下一个练习我们将学习 Markdown 的引用语法。
