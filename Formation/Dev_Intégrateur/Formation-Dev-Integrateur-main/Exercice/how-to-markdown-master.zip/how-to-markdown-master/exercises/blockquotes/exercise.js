'use strict';

module.exports = require('../../utils/problem')(__dirname);
