# Neat!

You made a great quote from a great play! Blockquotes are useful and handy in email to emulate reply text. They are often used in conversation at **GitHub** for replies to specific comments.

In the next exercise we will take a look at code in Markdown.
