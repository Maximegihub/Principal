# Success!

There's nothing strange, right? Everything is obvious.

In all of the next exercises you will have to add headings with the name of the current exercise.

In the next exercise we will take a look at emphasis in Markdown.
